#### Lab 1 : Learning Basic Linux Commands 

#### OS Used : Manjaro Linux x86_64

1. **Command Name:** ls

   **Syntax** : *ls* [option] [directory]

   **Usage** : The *ls* command lists files and directories within the file system and shows detailed information about them

   **Commands Used:**

   * ls => It lists all the unhidden files and directories within current directory.
   * ls Lab1 => It lists all the files and directories of directory
   * ls -l Lab1 => It lists files in long listing format which includes: 
     * The file type
     * The file permissions
     * Number of hard links to the file
     * File owner
     * File group
     * File Size
     * Date and Time
     * File name

   **Output:**

   ![image-20230411191015447](/home/tyzrex/.config/Typora/typora-user-images/image-20230411191015447.png)

   ---

   <div style="page-break-after: always; break-after: page;"></div>

2. **Command Name** : cd 

   **Syntax**: *cd* [directory]

   **Usage**: The *cd* command is used to change the working directory.

   **Commands Used**:

   * cd => The *cd* command takes us to the home directory of the current user
   * cd Documents/College-Repo-Fourth-Semester/Operating\ System/Practical-Stuff/ => It changes the working directory to the specified directory.
   * cd .. => Go up to the parent directory of the current directory

   **Output**:

   ![image-20230411192506949](/home/tyzrex/.config/Typora/typora-user-images/image-20230411192506949.png)

   ---

   <div style="page-break-after: always; break-after: page;"></div>

3. **Command Name** : grep

   **Syntax**:

   **Usage**:

   **Commands Used**:

   * =>
   * =>

   **Output**:

   

   ---

   <div style="page-break-after: always; break-after: page;"></div>

4. **Command Name** : su/sudo

   **Syntax**: 

   **Usage**: 

   **Commands Used**:

   * =>
   * =>

   **Output**:

   ---

   <div style="page-break-after: always; break-after: page;"></div>

5. **Command Name** : pwd

   **Syntax**: *pwd*

   **Usage**: This command prints the name of the current/working directory

   **Commands Used**:

   * pwd => Prints the name of the current/working directory
   * =>

   **Output**:

   

   ---

   <div style="page-break-after: always; break-after: page;"></div>

6. **Command Name** : mv

   **Syntax**: *mv* [option] [source] [target]

   **Usage**: This command is used to move or rename files or directories

   **Commands Used**:

   * mv OS_LabWorks_Part-1.pdf Practical-Stuff/ => Moves the file into the existing Practical-Stuff directory.
   * mv OS_LabWorks_Part-1.pdf OS_Renamed.pdf => Renames the file into a new name.
   * mv file1 file2 file3 Lab1/ => Move multiple files to an existing directory, keeping the filenames unchanged.
   * mv -f file1 Lab1/ => This command doesn’t prompt for confirmation before overwriting existing files
   * mv -i file1 Lab1/ => This command prompts for confirmation before overwriting existing files

   **Output**:

   <img src="/home/tyzrex/.config/Typora/typora-user-images/image-20230413071914703.png" alt="image-20230413071914703" style="zoom:67%;" />

   <img src="/home/tyzrex/.config/Typora/typora-user-images/image-20230413072047046.png" alt="image-20230413072047046" style="zoom:67%;" />

   ---

   <div style="page-break-after: always; break-after: page;"></div>

7. **Command Name** :   cp 

   **Syntax**: *cp* [option] [source] [target]

   **Usage**: This command is used to copy files and directories from a source to a target destination.

   **Commands Used**:

   * cp OS_Renamed.pdf Lab1/ => This copies the file to the given destination.
   * =>

   **Output**:

   ---

8. **Command Name** : cd 

   **Syntax**:

   **Usage**:

   **Commands Used**:

   * =>
   * =>

   **Output**:

   ---

9. **Command Name** : cd 

   **Syntax**:

   **Usage**:

   **Commands Used**:

   * =>
   * =>

   **Output**:

   ---

10. **Command Name** : cd 

    **Syntax**:

    **Usage**:

    **Commands Used**:

    * =>
    * =>

    **Output**:

    ---

11. **Command Name** : cd 

    **Syntax**:

    **Usage**:

    **Commands Used**:

    * =>
    * =>

    **Output**:

    ---

12. **Command Name** : cd 

    **Syntax**:

    **Usage**:

    **Commands Used**:

    * =>
    * =>

    **Output**:

    ---

13. **Command Name** : cd 

    **Syntax**:

    **Usage**:

    **Commands Used**:

    * =>
    * =>

    **Output**:

    ---

14. **Command Name** : cd 

    **Syntax**:

    **Usage**:

    **Commands Used**:

    * =>
    * =>

    **Output**:

    ---

15. **Command Name** : cd 

    **Syntax**:

    **Usage**:

    **Commands Used**:

    * =>
    * =>

    **Output**:

    ---

    

